
import { useEffect, useMemo, useState } from "react";
import { Routes, Route, NavLink } from "react-router-dom";

function Home() {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((r) => r.json())
      .then(setEmployees);
  }, []);

  const filtered = useMemo(() =>
    employees.filter(e => e.name.toLowerCase().includes(search.toLowerCase())),
    [employees, search]
  );

  return (
    <div className="container py-4">
      <div className="hero mb-4">
        <h1>Sreenandha PR</h1>
        <p>Modern Employee Dashboard built with React + Vite</p>
      </div>

      <div className="row text-center g-3 mb-4">
        <div className="col-md-4"><div className="stat"><h3>{employees.length}</h3><p>Total Employees</p></div></div>
        <div className="col-md-4"><div className="stat"><h3>10</h3><p>API Records</p></div></div>
        <div className="col-md-4"><div className="stat"><h3>100%</h3><p>Responsive</p></div></div>
      </div>

      <input className="form-control mb-3" placeholder="Search employee..." value={search} onChange={e=>setSearch(e.target.value)} />

      <div className="row g-3">
        {filtered.map(emp=>(
          <div className="col-md-6 col-lg-4" key={emp.id}>
            <div className="card h-100 shadow-sm border-0 rounded-4">
              <div className="card-body">
                <h5>{emp.name}</h5>
                <p>{emp.company.name}</p>
                <p>{emp.email}</p>
                <p>{emp.phone}</p>
                <span className="badge bg-primary">{emp.address.city}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function EmployeeForm() {
  const [form, setForm] = useState({name:"",designation:"",location:"",salary:""});
  const change=e=>setForm({...form,[e.target.name]:e.target.value});
  const submit=e=>{e.preventDefault(); alert("Employee Registered Successfully!"); setForm({name:"",designation:"",location:"",salary:""});};
  return (
    <div className="container py-4">
      <div className="form-card">
        <h2>Employee Registration</h2>
        <form onSubmit={submit}>
          {["name","designation","location","salary"].map(f=>(
            <div className="mb-3" key={f}>
              <label className="form-label text-capitalize">{f}</label>
              <input type={f==="salary"?"number":"text"} name={f} className="form-control" value={form[f]} onChange={change} required />
            </div>
          ))}
          <button className="btn btn-primary w-100">Submit</button>
        </form>
      </div>
    </div>
  );
}

export default function App(){
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <NavLink className="navbar-brand" to="/">Sreenandha PR</NavLink>
          <div className="navbar-nav ms-auto">
            <NavLink className="nav-link" to="/">Dashboard</NavLink>
            <NavLink className="nav-link" to="/form">Employee Form</NavLink>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/form" element={<EmployeeForm/>}/>
      </Routes>
    </>
  );
}
